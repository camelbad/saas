
public class Worker {
    int worker_id;
    String worker_add;
    
}
